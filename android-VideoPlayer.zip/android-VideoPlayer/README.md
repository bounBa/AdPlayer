Android Video Player Sample
===========================

This repo has been migrated to [github.com/android/media-samples][1]. Please check that repo for future updates. Thank you!

[1]: https://github.com/android/media-samples
